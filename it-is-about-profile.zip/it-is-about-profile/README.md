# it is about profile

A Pen created on CodePen.io. Original URL: [https://codepen.io/dbiniyam/pen/QWXpBBz](https://codepen.io/dbiniyam/pen/QWXpBBz).

bini